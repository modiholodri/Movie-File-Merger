## :open_file_folder: MFM Program Folder :open_file_folder:

The MFM Program folder contains 
- the MFM excutable
- short instructions
- the MediaInfo DLL
- the standard ini file
- this readme
